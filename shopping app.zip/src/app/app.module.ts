import { ProfileComponent } from './pages/profile/profile.component';
import { CameraComponent } from './pages/camera/camera.component';
import { ReceiptsComponent } from './pages/receipts/receipts.component';
import { PaymentsComponent } from './pages/payments/payments.component';
import { OrderComponent } from './pages/order/order.component';

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CartModelPageModule} from './pages/cart-model/cart-model.module';
import { ItemsComponent } from './pages/items/items.component';
import { AboutComponent } from './pages/about/about.component';
import { Camera } from '@ionic-native/camera/ngx';






@NgModule({
  declarations: [AppComponent,ItemsComponent,AboutComponent,OrderComponent, PaymentsComponent,ReceiptsComponent,CameraComponent,ProfileComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule,CartModelPageModule],
  providers: [
    StatusBar,
    SplashScreen,
    Camera,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
