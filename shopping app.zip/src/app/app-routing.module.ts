import { ProfileComponent } from './pages/profile/profile.component';
import { CameraComponent } from './pages/camera/camera.component';
import { ReceiptsComponent } from './pages/receipts/receipts.component';
import { PaymentsComponent } from './pages/payments/payments.component';
import { AboutComponent } from './pages/about/about.component';
import { OrderComponent } from './pages/order/order.component';
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { ItemsComponent } from './pages/items/items.component';




const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'cart-model',
    loadChildren: () => import('./pages/cart-model/cart-model.module').then( m => m.CartModelPageModule),
   
  },
  
  { path:'items', component: ItemsComponent},
  { path:'order', component: OrderComponent},
  { path: 'about', component: AboutComponent},
  { path: 'payments', component: PaymentsComponent},
  { path: 'receipts', component: ReceiptsComponent},
   { path: 'camera', component: CameraComponent},
   { path: 'profile', component: ProfileComponent}
  
];


@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
