import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
// import { Component, OnInit } from '@angular/core';
import{ActivatedRoute} from '@angular/router';
// import { CartService } from 'src/app/services/cart.service';
import {CartService} from './../../services/cart.service';
import { ModalController } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs'; 
import { CartModelPage} from './../../pages/cart-model/cart-model.page';


@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.scss'],
})
export class ItemsComponent implements OnInit {
  cart = [];
  products = [];
  cartItemCount: BehaviorSubject<number>;
  
   @ViewChild('cart', {static: false, read: ElementRef}) fab: ElementRef;
  
  constructor(private userInfo:CartService,private route:ActivatedRoute,private cartService: CartService, private modalCtrl:ModalController) { }
  detail:any[];
  id:any[];
 
    ngOnInit() {
    let id = this.route.snapshot.paramMap.get("id");
 
  
   this.detail = this.userInfo.getinfo();
   console.log(this.detail);
    

 this.products = this.cartService.getProducts();
     this.cart = this.cartService.getCart();
     this.cartItemCount = this.cartService.getCartItemCount()
   
    }
    addToCart(detail){
      this.cartService.addProduct(detail);
     
    }
 
    async openCart() {
      let modal =  await this.modalCtrl.create({
        component: CartModelPage,
        cssClass:'cart-modal'
      });
       modal.present();
    }
    getCartItemCount(){
      return this.cartItemCount;
    }
}
